---
type: "hub"
title: "Deliverables Hub"
created: "{{date}}"
updated: "{{date}}"
status: "active"
domain: "Blog Content Brain"
tags: [type-hub, deliverables, active]
---

# Deliverables Hub

## Parent

- [[Index]]
- [[Dashboard]]

## Core Links

- [[Hot]]
- [[Overview]]

## Notes

Add generated notes here and keep this hub linked both ways.
