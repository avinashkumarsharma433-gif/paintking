"""Agentic SEO script package."""
